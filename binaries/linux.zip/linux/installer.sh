# move the binary to PATH folder to be able to run it everywhere
cp journal /usr/local/bin/journal
